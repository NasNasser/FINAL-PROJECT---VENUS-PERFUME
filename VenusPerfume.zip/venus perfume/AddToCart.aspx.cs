﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;


namespace venus_perfume
{
    public partial class Test : System.Web.UI.Page
    {
        SqlConnection conn;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                if (Session["Buyitems"] == null)
                {

                    Button1.Enabled = false;
                }
                else
                {
                    Button1.Enabled = true;
                }

                // adding product to Gridview

                Session["addproduct"] = "false";
                DataTable dt = new DataTable();
                DataRow dr;
                dt.Columns.Add("sno");
                dt.Columns.Add("pid");
                dt.Columns.Add("pname");
                dt.Columns.Add("pimage");
                dt.Columns.Add("pprice");
                dt.Columns.Add("pquantity");
                dt.Columns.Add("ptotalprice");
              //  dt.Columns.Add("quantity");




                if (Request.QueryString["id"] != null)
                {
                    if (Session["Buyitems"] == null)
                    {

                        dr = dt.NewRow();
                        conn = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["DB"].ConnectionString);

                        SqlDataAdapter sda = new SqlDataAdapter("Select * from product where ProductId=" + Request.QueryString["id"], conn);
                        DataSet ds = new DataSet();
                        sda.Fill(ds);

                        dr["sno"] = 1;
                      //  dr["Qty"] = 2;
                        dr["pid"] = ds.Tables[0].Rows[0]["ProductId"].ToString();
                        dr["pname"] = ds.Tables[0].Rows[0]["Pname"].ToString();
                        dr["pimage"] = ds.Tables[0].Rows[0]["Pimage"].ToString();
                        dr["pprice"] = ds.Tables[0].Rows[0]["Pprice"].ToString();

                        dr["pquantity"] =  Request.QueryString["quantity"];
                        string qty  = Request.QueryString["quantity"];
                        int price = Convert.ToInt32(ds.Tables[0].Rows[0]["Pprice"].ToString());
                        Int16 Quantity = Convert.ToInt16(qty);
                        int TotalPrice = price * Quantity;
                        dr["ptotalprice"] = TotalPrice;

                        dt.Rows.Add(dr);
                        GridView1.DataSource = dt;
                        GridView1.DataBind();
                        Session["buyitems"] = dt;
                        Button1.Enabled = true;
                       Response.Redirect("AddToCart.aspx");
                    }
                    else

                    {
                        dt = (DataTable)Session["buyitems"];
                        int sr;
                        sr = dt.Rows.Count;

                        dr = dt.NewRow();
                        conn = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["DB"].ConnectionString);

                        SqlDataAdapter sda = new SqlDataAdapter(" select * from product where ProductId= " + Request.QueryString["id"], conn);
                        DataSet ds = new DataSet();
                        sda.Fill(ds);

                        dr["sno"] = sr + 1;
                        dr["pid"] = ds.Tables[0].Rows[0]["ProductId"].ToString();
                        dr["pname"] = ds.Tables[0].Rows[0]["Pname"].ToString();
                        dr["pimage"] = ds.Tables[0].Rows[0]["Pimage"].ToString();
                        dr["pprice"] = ds.Tables[0].Rows[0]["Pprice"].ToString();
                        dr["pquantity"] = Request.QueryString["quantity"];

                        double price = double.Parse( ds.Tables[0].Rows[0]["pprice"].ToString());
                        int Quantity = Convert.ToInt16(Request.QueryString["quantity"].ToString());
                        double TotalPrice = price * Quantity;
                        dr["ptotalprice"] = TotalPrice;

                        dt.Rows.Add(dr);
                        GridView1.DataSource = dt;
                        GridView1.DataBind();
                        Session["buyitems"] = dt;
                        Button1.Enabled = true;
                       Response.Redirect("AddToCart.aspx");
                    }

                }

                else
                {
                    if (Session["buyitems"] != null)
                    {
                        dt = (DataTable)Session["buyitems"];
                        GridView1.DataSource = dt;
                        GridView1.DataBind();
                        if (GridView1.Rows.Count > 0)
                        {
                        }
                    }

                }

               


                string OrderDate = DateTime.Now.ToShortDateString();
                Session["OrderDate"] = OrderDate;
                orderid();
            }
        }


            // Calculating Final Price..
            public int grandtotal()
            {
                DataTable dt = new DataTable();
                dt = (DataTable)Session["buyitems"];
                int nrow = dt.Rows.Count;
                int i = 0;
                int TotalPrice = 0;
                while (i < nrow)
                {
                    TotalPrice = TotalPrice + Convert.ToInt32(dt.Rows[i]["pprice"].ToString());
                    i = i++;
                }
                return TotalPrice;
            }
            public void orderid()
            {
                String alpha = "abcdefghIjklmNopqrStuvwXyz123456789";
                Random r = new Random();
                char[] myArray = new char[5];
                for (int i = 0; i < 5; i++)
                {
                    myArray[i] = alpha[(int)(35 * r.NextDouble())];

                }
                String orderid;
                orderid = "OrderId: " + DateTime.Now.Hour.ToString() + DateTime.Now.Second.ToString() + DateTime.Now.Day.ToString() + DateTime.Now.Month.ToString() + DateTime.Now.Year.ToString()
                    + new string(myArray) + DateTime.Now.Minute.ToString() + DateTime.Now.Second.ToString();
                Session["orderid"] = orderid;
            }


            protected void Button1_Click(object sender, EventArgs e)
            {
              
            // if session is null redirecting to login else replacing the order..

                if (Session["username"] == null)
                {
                    Response.Redirect("Login.aspx");
                }
                else
                {
                    if (GridView1.Rows.Count.ToString() == "0")
                    {
                        Response.Write("<script>alert('Your cart is Empty.You can't place the order');</script>");
                    }
                    else
                    {
                        Response.Redirect("Payment.aspx");
                    }
                }

            }

        protected void GridView1_RowDeleting1(object sender, GridViewDeleteEventArgs e)
        {
            DataTable dt = new DataTable();
            dt = (DataTable)Session["Buyitems"];

            for (int i = 0; i <= dt.Rows.Count - 1; i++)

            {
                int sr;
                int sr1;
                string qdata;
                string dtdata;
                sr = Convert.ToInt32(dt.Rows[i]["sno"].ToString());
                TableCell cell = GridView1.Rows[e.RowIndex].Cells[0];
                qdata = cell.Text;
                dtdata = sr.ToString();
                sr1 = Convert.ToInt32(qdata);

                if (sr == sr1)
                {
                    dt.Rows[i].Delete();
                    dt.AcceptChanges();
                    break;

                }

            }
            // Setting sno after deleting row item from cart..
            for (int i = 1; i <= dt.Rows.Count; i++)
            {
                dt.Rows[i - 1]["sno"] = i;
                dt.AcceptChanges();

            }
            Session["Buyitems"] = dt;
            Response.Redirect("AddToCart.aspx");
        }

        protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
    }
