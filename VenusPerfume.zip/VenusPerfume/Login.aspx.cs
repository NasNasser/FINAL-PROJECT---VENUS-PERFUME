﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;

namespace venus_perfume
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        SqlConnection conn;
        SqlDataReader dr;
        protected void Page_Load(object sender, EventArgs e)
        {
            {
                AppDomain.CurrentDomain.SetData("DataDirectory", Server.MapPath("~/App_Data"));
                conn = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["DB"].ConnectionString);
              

            }
        }

        protected void Button1_Click(object sender, EventArgs e)
        {

            conn.Open();
            string sql = "SELECT * FROM UserData where username='" + txtusername.Text + "' AND password='" + txtpassword.Text + "'";
            SqlCommand cmd = new SqlCommand(sql, conn);
            dr = cmd.ExecuteReader();
            if (dr.Read())
            {
               Response.Write("...WELCOME TO VENUS PERFUME WEBSITE...");
                Session["username"] = txtusername.Text;
                Response.Redirect("Products.aspx");
            }
            else
            {
                Response.Write("Invalid Login please check username and password");
            }
            conn.Close();
           
        }

    }
}
