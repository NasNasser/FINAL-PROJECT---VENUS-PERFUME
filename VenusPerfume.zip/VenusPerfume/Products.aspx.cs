﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;


namespace venus_perfume
{
    public partial class WebForm3 : System.Web.UI.Page
    {
          SqlConnection conn;
        protected void Page_Load(object sender, EventArgs e)

        {
 
            conn = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["DB"].ConnectionString);


            Session["addproduct"] = "false";

            //Login Session
            if (Session["username"] != null)
            {
                Label4.Text = "Logged in as " + Session["username"].ToString();
                HyperLink1.Visible = false;
                Button1.Visible = true;
            }
            else
            {
                Label4.Text = "Hello you can Login here....";
                HyperLink1.Visible = true;
                Button1.Visible = false;
            }

        }

        protected void DataList1_ItemCommand(object source, DataListCommandEventArgs e)
        {
            Session["addproduct"] = "true";
            if (e.CommandName == "AddToCart")
            {

                DropDownList list = (DropDownList)(e.Item.FindControl("DropDownList1"));
                Response.Redirect("AddToCart.aspx?id=" + e.CommandArgument.ToString() + "&quantity=" + list.SelectedItem.ToString());

            }
        }
        // Searshing Product...
        

        protected void DataList1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        protected void ImageButton1_Click1(object sender, ImageClickEventArgs e)
        {
            
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            Session.Abandon();

          // Response.Redirect("Products.aspx");
           Label4.Text = " You have logout Successfully...";

        }

        protected void ImageButton2_Click(object sender, ImageClickEventArgs e)
        {
           // SqlConnection con = new SqlConnection("Data Source = .; Initial catalog = DB; Integrated Security = true;");
            SqlDataAdapter sda = new SqlDataAdapter(" Select * from Product where (Pname like '%"+TextBox1.Text+"%') or (ProductId like '%"+TextBox1.Text+"%')",conn);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            DataList1.DataSourceID = null;
            DataList1.DataSource = dt;
            DataList1.DataBind();



        }
    }

}