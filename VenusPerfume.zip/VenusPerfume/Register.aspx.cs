﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;


namespace venus_perfume
{
    public partial class WebForm2 : System.Web.UI.Page
    {
        SqlConnection conn;
        //= new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["DB"].ConnectionString);
        protected void Page_Load(object sender, EventArgs e)
        {
            {
               AppDomain.CurrentDomain.SetData("DataDirectory", Server.MapPath("~/App_Data"));
               conn = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["DB"].ConnectionString);

            }
        }

        protected void btnregister_Click(object sender, EventArgs e)
        {
            string sql =" insert into UserData values( "+ txtid.Text+" , '"+txtusername.Text +"' , '" + txtemail.Text + " ', '"+ txtpassword.Text +"')";
            SqlCommand cmd = new SqlCommand(sql, conn);

            conn.Open();
            cmd.ExecuteNonQuery();
            conn.Close();
            Response.Write("WELCOME! RECORD INSERTED...");
        }

        protected void btnreset_Click(object sender, EventArgs e)
        {

            txtusername.Text = "";
            txtemail.Text = "";
            txtpassword.Text = "";
            txtpassword2.Text = ""; 

        }
    }
}