﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;

namespace venus_perfume
{
    public partial class Payment : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            /*SqlConnection con = new SqlConnection("Data Source=.;Initial catalog=DB;Integrated Security=true;");
            con.Open();
            SqlCommand cmd = new SqlCommand("insert into CardDetails" + "(Fname,Lname,CardNo,ExpiryDate,CW,BillingAddr) values (@Fname,@Lname,@CardNo,@ExpiryDate,@CW,@BillingAddr");
            cmd.Parameters.AddWithValue("@Fname", TextBox1.Text);
            cmd.Parameters.AddWithValue("@Lname", TextBox2.Text);
            cmd.Parameters.AddWithValue("@CardNo", TextBox3.Text);
            cmd.Parameters.AddWithValue("@ExpirtyDate", TextBox4.Text);
            cmd.Parameters.AddWithValue("@CW", TextBox5.Text);
            cmd.Parameters.AddWithValue("@BillingAddr", TextBox6.Text);

            cmd.ExecuteNonQuery();
            con.Close();*/
            //Response.Write("<script>alert('Payment Made Successfully');</script>");
            //Session["address"] = TextBox6.Text;
            //Response.Redirect("pdf_generate.aspx");
            Response.Write("Payment Made Successfully");

        }
    }
}